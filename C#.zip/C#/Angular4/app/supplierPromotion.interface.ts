﻿export class ISupplierPromotion {
    brand: string;
    fromdate: string;
    todate: string;
    managers: ICategoryManager[];
    buyers: SelectListItem[];
    brands: SelectListItem[];
    suppliers: SelectListItem[];
    showprojections: SelectListItem[];
    sbus: SelectListItem[];
    plannedoptions: SelectListItem[];
    familygroups: SelectListItem[];

    //constructor(public categoryManager: ICategoryManager, public itemName: string) { }

}
export class ICategoryManager {
    public constructor(public managerid: string, public managername: string) { }
}

export class IBuyer {
    public constructor(public id: string, public name: string) { }
}

export class ISupplier {
    public constructor(public id: string, public name: string) { }
}

export class ISBU {
    public constructor(public id: string, public name: string) { }
}

export class IPlannedUnPlanned {
    public constructor(public id: string, public name: string) { }
}

export class IShowProjections {
    public constructor(public id: string, public name: string) { }
}

export class IFamilyGroups {
    public constructor(public id: string, public name: string) { }
}
export class SelectListItem {
    public constructor(public id: string, public name: string) { }
}