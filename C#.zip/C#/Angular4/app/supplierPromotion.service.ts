﻿import { Injectable } from '@angular/core';
import { ISupplierPromotion } from './supplierPromotion.interface';
import { Http, Response } from '@angular/http';
import { Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';


@Injectable()
export class SupplierPromotionService {
    //public promotionData: ISupplierPromotion[] = [];
    
    private _serviceUrl = './app/api/supplierPromotion.json'

    constructor(private _http: Http) { }

    //Login(data: any) {
    //    return new Promise(resolve => {
    //        const header = new Headers();
    //        header.append('Content-Type', 'application/json');
    //        this.http.post(this.baseUrl + "/EmployeeLogin", data, { headers: header }).map(res => res.json())
    //            .subscribe(reponse => {
    //                console.log(reponse)
    //                //this.employeesData = reponse;
    //                //resolve(this.employeesData);
    //            },
    //            error => console.log(error),
    //            () => console.log('Finished')
    //            );


    //    });
    //}

    getPromotions(): Observable<ISupplierPromotion> {
        return this._http.get(this._serviceUrl)
            .map((response: Response) => <ISupplierPromotion>response.json())
            .catch(this.handleError);
    }
    private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error) || 'server error';
    }
   
}
