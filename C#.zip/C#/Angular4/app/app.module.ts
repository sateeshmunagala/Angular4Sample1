import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { SupplierPromotionService } from './supplierPromotion.service';

import { Root1Component } from './root1/root1.component';
import { Root2Component } from './root2/root2.component';


const appRoutes: Routes = [
    { path: 'root1', component: Root1Component },
    { path: 'root2', component: Root2Component }
];


@NgModule({
    imports:
    [
        BrowserModule,
        HttpModule,
        FormsModule      
        //RouterModule.forRoot(appRoutes)
    ],
    declarations: [
        AppComponent,
        Root1Component,
        Root2Component
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule { }
