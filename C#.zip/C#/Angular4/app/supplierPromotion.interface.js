"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ISupplierPromotion = (function () {
    function ISupplierPromotion() {
    }
    return ISupplierPromotion;
}());
exports.ISupplierPromotion = ISupplierPromotion;
var ICategoryManager = (function () {
    function ICategoryManager(managerid, managername) {
        this.managerid = managerid;
        this.managername = managername;
    }
    return ICategoryManager;
}());
exports.ICategoryManager = ICategoryManager;
var IBuyer = (function () {
    function IBuyer(id, name) {
        this.id = id;
        this.name = name;
    }
    return IBuyer;
}());
exports.IBuyer = IBuyer;
var ISupplier = (function () {
    function ISupplier(id, name) {
        this.id = id;
        this.name = name;
    }
    return ISupplier;
}());
exports.ISupplier = ISupplier;
var ISBU = (function () {
    function ISBU(id, name) {
        this.id = id;
        this.name = name;
    }
    return ISBU;
}());
exports.ISBU = ISBU;
var IPlannedUnPlanned = (function () {
    function IPlannedUnPlanned(id, name) {
        this.id = id;
        this.name = name;
    }
    return IPlannedUnPlanned;
}());
exports.IPlannedUnPlanned = IPlannedUnPlanned;
var IShowProjections = (function () {
    function IShowProjections(id, name) {
        this.id = id;
        this.name = name;
    }
    return IShowProjections;
}());
exports.IShowProjections = IShowProjections;
var IFamilyGroups = (function () {
    function IFamilyGroups(id, name) {
        this.id = id;
        this.name = name;
    }
    return IFamilyGroups;
}());
exports.IFamilyGroups = IFamilyGroups;
var SelectListItem = (function () {
    function SelectListItem(id, name) {
        this.id = id;
        this.name = name;
    }
    return SelectListItem;
}());
exports.SelectListItem = SelectListItem;
//# sourceMappingURL=supplierPromotion.interface.js.map