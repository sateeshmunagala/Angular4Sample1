import { Component } from '@angular/core';

@Component({
    templateUrl: 'root1.component.html',
    moduleId: module.id
})
export class Root1Component { }
