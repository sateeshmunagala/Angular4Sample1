import { Component } from '@angular/core';

@Component({
    templateUrl: 'root2.component.html',
    moduleId: module.id
})
export class Root2Component { }
