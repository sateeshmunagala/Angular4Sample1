import { Component, OnInit } from '@angular/core';
import { SupplierPromotionService } from './supplierPromotion.service';
import {
    ISupplierPromotion, ICategoryManager, IBuyer, ISupplier,
    ISBU, IPlannedUnPlanned, IShowProjections, IFamilyGroups, SelectListItem
} from './supplierPromotion.interface';


@Component({
    selector: 'my-app',
    templateUrl: 'app.component.html',
    styleUrls: ['app.component.css'],
    providers: [SupplierPromotionService],
    moduleId: module.id
})
export class AppComponent implements OnInit {
    brand: string;
    fromdate: string;
    todate: string;
    supplierPromotions: ISupplierPromotion;
    managers: ICategoryManager[] = [];

    suppliers: SelectListItem[] = [];
    buyers: SelectListItem[] = [];
    brands: SelectListItem[] = [];
    sbus: SelectListItem[] = [];
    plannedOptions: SelectListItem[] = [];
    projections: SelectListItem[] = [];
    familyGroups: SelectListItem[] = [];

    errorMessage: string;

    selectedManager: string;
    selectedBuyer: string;
    selectedSupplier: string;
    selectedBrands: string;
    selectedSBU: string;
    selectedPlannedOption: string;
    selectedProjections: string;
    selectedFamilyGroup: string;

    fromDate: string;
    toDate: string;

    constructor(private _supplierPromotionService: SupplierPromotionService) {

        //this.managers.push('Manager1');
        //this.managers.push('Manager2');
        //console.log(this.managers);
        //console.log(this.supplierPromotions.managers);

    };

    SubmitForm(): void {

        console.log(this.selectedManager);
        console.log(this.selectedBuyer);
        console.log(this.selectedSupplier);
        console.log(this.selectedBrands);
        console.log(this.selectedSBU);
        console.log(this.selectedPlannedOption);
        console.log(this.selectedProjections);
        console.log(this.selectedManager);
        console.log(this.selectedFamilyGroup);
        console.log(this.fromDate);
        console.log(this.toDate);
    }

    ngOnInit(): void {
        this._supplierPromotionService.getPromotions()
            .subscribe(data => {
                this.supplierPromotions = data;
                let i = 0;
              
                this.supplierPromotions.managers.forEach(mgr => {
                    //console.log(mgr);
                    this.managers.push(new ICategoryManager(mgr.managerid, mgr.managername));
                })

                this.supplierPromotions.suppliers.forEach(mgr => {
                    //console.log(mgr);
                    this.suppliers.push(new SelectListItem(mgr.id, mgr.name));
                })

                this.supplierPromotions.buyers.forEach(mgr => {
                    //console.log(mgr);
                    this.buyers.push(new SelectListItem(mgr.id, mgr.name));
                })

                this.supplierPromotions.showprojections.forEach(mgr => {
                    //console.log(mgr);
                    this.projections.push(new SelectListItem(mgr.id, mgr.name));
                })

                this.supplierPromotions.brands.forEach(mgr => {
                    //console.log(mgr);
                    this.brands.push(new SelectListItem(mgr.id, mgr.name));
                })

                this.supplierPromotions.sbus.forEach(mgr => {
                    //console.log(mgr);
                    this.sbus.push(new SelectListItem(mgr.id, mgr.name));
                })
                this.supplierPromotions.plannedoptions.forEach(mgr => {
                    //console.log(mgr);
                    this.sbus.push(new SelectListItem(mgr.id, mgr.name));
                })

                this.supplierPromotions.familygroups.forEach(mgr => {
                    //console.log(mgr);
                    this.sbus.push(new SelectListItem(mgr.id, mgr.name));
                })
            },

            error => this.errorMessage = <any>error
            );

    }

    name = 'Angular 2';
}
