"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var supplierPromotion_service_1 = require("./supplierPromotion.service");
var supplierPromotion_interface_1 = require("./supplierPromotion.interface");
var AppComponent = (function () {
    function AppComponent(_supplierPromotionService) {
        //this.managers.push('Manager1');
        //this.managers.push('Manager2');
        //console.log(this.managers);
        //console.log(this.supplierPromotions.managers);
        this._supplierPromotionService = _supplierPromotionService;
        this.managers = [];
        this.suppliers = [];
        this.buyers = [];
        this.brands = [];
        this.sbus = [];
        this.plannedOptions = [];
        this.projections = [];
        this.familyGroups = [];
        this.name = 'Angular 2';
    }
    ;
    AppComponent.prototype.SubmitForm = function () {
        console.log(this.selectedManager);
        console.log(this.selectedBuyer);
        console.log(this.selectedSupplier);
        console.log(this.selectedBrands);
        console.log(this.selectedSBU);
        console.log(this.selectedPlannedOption);
        console.log(this.selectedProjections);
        console.log(this.selectedManager);
        console.log(this.selectedFamilyGroup);
        console.log(this.fromDate);
        console.log(this.toDate);
    };
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._supplierPromotionService.getPromotions()
            .subscribe(function (data) {
            _this.supplierPromotions = data;
            var i = 0;
            _this.supplierPromotions.managers.forEach(function (mgr) {
                //console.log(mgr);
                _this.managers.push(new supplierPromotion_interface_1.ICategoryManager(mgr.managerid, mgr.managername));
            });
            _this.supplierPromotions.suppliers.forEach(function (mgr) {
                //console.log(mgr);
                _this.suppliers.push(new supplierPromotion_interface_1.SelectListItem(mgr.id, mgr.name));
            });
            _this.supplierPromotions.buyers.forEach(function (mgr) {
                //console.log(mgr);
                _this.buyers.push(new supplierPromotion_interface_1.SelectListItem(mgr.id, mgr.name));
            });
            _this.supplierPromotions.showprojections.forEach(function (mgr) {
                //console.log(mgr);
                _this.projections.push(new supplierPromotion_interface_1.SelectListItem(mgr.id, mgr.name));
            });
            _this.supplierPromotions.brands.forEach(function (mgr) {
                //console.log(mgr);
                _this.brands.push(new supplierPromotion_interface_1.SelectListItem(mgr.id, mgr.name));
            });
            _this.supplierPromotions.sbus.forEach(function (mgr) {
                //console.log(mgr);
                _this.sbus.push(new supplierPromotion_interface_1.SelectListItem(mgr.id, mgr.name));
            });
            _this.supplierPromotions.plannedoptions.forEach(function (mgr) {
                //console.log(mgr);
                _this.sbus.push(new supplierPromotion_interface_1.SelectListItem(mgr.id, mgr.name));
            });
            _this.supplierPromotions.familygroups.forEach(function (mgr) {
                //console.log(mgr);
                _this.sbus.push(new supplierPromotion_interface_1.SelectListItem(mgr.id, mgr.name));
            });
        }, function (error) { return _this.errorMessage = error; });
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: 'app.component.html',
        styleUrls: ['app.component.css'],
        providers: [supplierPromotion_service_1.SupplierPromotionService],
        moduleId: module.id
    }),
    __metadata("design:paramtypes", [supplierPromotion_service_1.SupplierPromotionService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map